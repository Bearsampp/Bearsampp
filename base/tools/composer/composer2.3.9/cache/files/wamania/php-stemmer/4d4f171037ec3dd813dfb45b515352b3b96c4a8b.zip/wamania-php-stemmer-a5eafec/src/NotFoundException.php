<?php

namespace Wamania\Snowball;

class NotFoundException extends \Exception
{

}
