# The Authentication Package [![Build Status](https://ci.joomla.org/api/badges/joomla-framework/authentication/status.svg?ref=refs/heads/2.0-dev)](https://ci.joomla.org/joomla-framework/authentication)

[![Latest Stable Version](https://poser.pugx.org/joomla/authentication/v/stable)](https://packagist.org/packages/joomla/authentication)
[![Total Downloads](https://poser.pugx.org/joomla/authentication/downloads)](https://packagist.org/packages/joomla/authentication)
[![Latest Unstable Version](https://poser.pugx.org/joomla/authentication/v/unstable)](https://packagist.org/packages/joomla/authentication)
[![License](https://poser.pugx.org/joomla/authentication/license)](https://packagist.org/packages/joomla/authentication)

The authentication package provides a simple interface to authenticate users in a Joomla Framework application. It is completely decoupled from the application class and provides the ability to implement custom authentication strategies.


## Installation via Composer

Add `"joomla/authentication": "2.0.*@dev"` to the require block in your composer.json and then run `composer install`.

```json
{
	"require": {
		"joomla/authentication": "2.0.*@dev"
	}
}
```

Alternatively, you can simply run the following from the command line:

```sh
composer require joomla/authentication "2.0.*@dev"
```

If you want to include the test sources and docs, use

```sh
composer require --prefer-source joomla/authentication "2.0.*@dev"
```
