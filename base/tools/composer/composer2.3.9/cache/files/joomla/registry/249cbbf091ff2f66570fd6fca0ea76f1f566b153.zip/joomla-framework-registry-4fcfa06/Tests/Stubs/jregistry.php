<?php
namespace Joomla\Registry\Tests\Stubs;

class JRegistry {
	public $foo = 'bar';
	public $nested = array('foo' => 'bar');
}