<?php

namespace Algo26\IdnaConvert\Exception;

use Exception;

class InvalidCharacterException extends Exception
{

}
