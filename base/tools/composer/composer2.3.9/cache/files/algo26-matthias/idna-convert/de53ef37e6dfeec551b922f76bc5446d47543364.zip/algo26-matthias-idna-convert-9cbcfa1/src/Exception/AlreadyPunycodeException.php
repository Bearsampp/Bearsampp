<?php

namespace Algo26\IdnaConvert\Exception;

use Exception;

class AlreadyPunycodeException extends Exception
{

}
