<?php

namespace Algo26\IdnaConvert\NamePrep;

interface NamePrepDataInterface
{
}
