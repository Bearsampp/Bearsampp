# 1.17.01.16

  * Quality: Happy new year! (Ivan Enderlin, 2017-01-16T08:52:04+01:00)

# 1.16.11.08

  * Documentation: New `README.md` file. (Ivan Enderlin, 2016-10-19T16:31:55+02:00)
  * Documentation: Update `support` properties. (Ivan Enderlin, 2016-10-05T20:39:14+02:00)

# 1.16.01.11

  * Quality: Drop PHP5.4. (Ivan Enderlin, 2016-01-11T09:15:26+01:00)
  * Quality: Run devtools:cs. (Ivan Enderlin, 2016-01-09T09:01:35+01:00)
  * Core: Remove `Hoa\Core`. (Ivan Enderlin, 2016-01-09T08:16:03+01:00)
  * Consistency: Use `Hoa\Consistency`. (Ivan Enderlin, 2015-12-08T11:11:27+01:00)

# 0.15.11.23

  * Fix phpDoc and a mistake on a static call. (Metalaka, 2015-11-21T17:44:35+01:00)
  * Add a `.gitignore` file. (Metalaka, 2015-11-21T17:39:21+01:00)
  * Test: Add test cases for the uncaught handler. (Ivan Enderlin, 2015-11-18T21:48:20+01:00)
  * Idle: Add uncaught handler. (Ivan Enderlin, 2015-11-18T21:47:40+01:00)
  * README: Add a better description and new usages. (Ivan Enderlin, 2015-11-18T21:36:03+01:00)
  * Test: Write test suite of `Hoa\Exception\Group`. (Ivan Enderlin, 2015-11-18T08:28:04+01:00)
  * Test: Write test suite of `Hoa\Exception\Error`. (Ivan Enderlin, 2015-11-17T22:30:14+01:00)
  * Test: Write test suite of `…\Exception\Exception`. (Ivan Enderlin, 2015-11-17T22:03:31+01:00)
  * Test: Write test suite of `Hoa\Exception\Idle`. (Ivan Enderlin, 2015-11-17T21:41:07+01:00)
  * Split from `Hoa\Core`. (Ivan Enderlin, 2015-11-13T08:58:45+01:00)

(first snapshot)
