<?php

namespace Negotiation;

final class AcceptCharset extends BaseAccept implements AcceptHeader
{
}
